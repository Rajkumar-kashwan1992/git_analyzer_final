(function() {
    'use strict';
    /* jshint camelcase: false */
    angular.module('wmsApp')
        .controller('mainCtrl', MainCtrl);

    MainCtrl.$inject = ['$scope', '$http'];

    function MainCtrl($scope, $http) {
        $scope.name="";
        $scope.date_from = document.getElementById("date_from").value;
        //$scope.date_from=$scope.date_from.toISOString().substring(0, 10);
        //var dt_fr=date_from.getDay()+"-"+date_from.getMonth()+"-"+date_from.getFullYear();
         //&scope.v = $filter('date')($scope, "dd/MM/yyyy");
        // $scope.dt_fr = $scope.date_from.getFullYear()+"-"+($scope.date_from.getMonth()+1)+"-"+$scope.date_from.getDate();
        $scope.date_to = document.getElementById("date_to").value;
       // var v = {{$scope.date_from.toISOString().substring(0, 10)}};
        $scope.search=function(){
            /*---------------------------------------
            if($scope.name!== null){
                $http.get("http://10.2.8.21:8000/gitapi/get_user_comment/"+$scope.name+"/?format=json"+"&from_date="+$scope.date_from.getFullYear()+"-"+($scope.date_from.getMonth()+1)+"-"+$scope.date_from.getDate()+"&to_date="+$scope.date_to.getFullYear()+"-"+($scope.date_to.getMonth()+1)+"-"+$scope.date_to.getDate())
                .success(function(response) {
                    //var a = $scope.date_from.getDay();

                //document.write($scope.date_from);
                console.log($scope.date_from);
                $scope.employees = response;

                }

            );
        }
        ---------------------------------------------*/
        /*----------------------------------------------------------*/
            if($scope.date_from === "" && $scope.date_to === ""){
                $http.get("http://10.2.8.21:8000/gitapi/get_user_comment/"+$scope.name+"/?format=json")
                .success(function(response) {
                    //var a = $scope.date_from.getDay();

                //document.write($scope.date_from);
                    console.log($scope.name);
                    $scope.employees = response;

                    }

                ).error(function(data, status) {
                     $scope.employees = null;
                      alert("Comment not found");
                    }
                );
            }

           else if($scope.date_to === "" ){
            $http.get("http://10.2.8.21:8000/gitapi/get_user_comment/"+$scope.name+"/?format=json&from_date="+$scope.date_from.getFullYear()+"-"+($scope.date_from.getMonth()+1)+"-"+$scope.date_from.getDate())
                .success(function(response) {
                    //var a = $scope.date_from.getDay();

                //document.write($scope.date_from);
                    console.log($scope.date_from);
                    $scope.employees = response;

                    }

                ).error(function(data, status) {
                     $scope.employees = null;
                      alert("Comment not found");
                    }
                );

           }

            else if($scope.date_from === "" ){
            $http.get("http://10.2.8.21:8000/gitapi/get_user_comment/"+$scope.name+"/?format=json&to_date="+$scope.date_to.getFullYear()+"-"+($scope.date_to.getMonth()+1)+"-"+$scope.date_to.getDate())
                .success(function(response) {
                    //var a = $scope.date_from.getDay();

                //document.write($scope.date_from);
                    console.log($scope.date_from);
                    $scope.employees = response;

                    }

                ).error(function(data, status) {
                     $scope.employees = null;
                      alert("Comment not found");
                    }
                );

           }
           else
           {
            $http.get("http://10.2.8.21:8000/gitapi/get_user_comment/"+$scope.name+"/?format=json"+"&from_date="+$scope.date_from.getFullYear()+"-"+($scope.date_from.getMonth()+1)+"-"+$scope.date_from.getDate()+"&to_date="+$scope.date_to.getFullYear()+"-"+($scope.date_to.getMonth()+1)+"-"+$scope.date_to.getDate())
                .success(function(response) {
                    //var a = $scope.date_from.getDay();

                //document.write($scope.date_from);
                console.log($scope.date_from);
                $scope.employees = response;

                }

            ).error(function(data, status) {
                     $scope.employees = null;
                      alert("Comment not found");
                    }
                );
           }







         /*----------------------------------------------------------*/
    }
        $scope.myfun = function(){
                $scope.head = "Git Comment info given by all users for"+ $scope.name;
            }
    }
})();

//"10.2.8.21:8000/gitapi/get_user_comment/"+$scope.name+"/"+$scope.date_from"+"/?format=json"

//http://10.2.8.21:8000/gitapi/get_user_comment/devendraratnam747/2016-07-28/?format=json
//10.2.8.21:8000/gitapi/get_user_comment/devendraratnam747/2016-7-28/?format=json
//10.2.8.21:8000/gitapi/get_user_comment/devendraratnam747/?format=json&from_date=2016-07-27&to_date=2016-07-29